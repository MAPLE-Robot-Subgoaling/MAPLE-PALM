Specs:
20 x 20
1 forest, 3 trees
1 goldmine
1 peasant
