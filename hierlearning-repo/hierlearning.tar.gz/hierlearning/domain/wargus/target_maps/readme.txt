Specs:
20 x 20
3 forests, 15 trees
2 goldmines
3 peasants
